export default () => {
    return `404`;
};
