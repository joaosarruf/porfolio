# My Portfolio #
Written in vanilla js.

If you have any questions you can message me on discord **elias.dev.**
*PS. I'm sure there are a lot of typos and bugs, so pull requests and forks are welcome*  

**FIGMA**: https://www.figma.com/community/file/1164933568884615740  
**LIVE**: [eliasdevis.github.io](https://eliasdevis.github.io/)

## TODO ##
- [ ] Page contacts
- [ ] Blog maybe
- [ ] Animation
- [ ] Improve images
- [ ] Delete unused code
